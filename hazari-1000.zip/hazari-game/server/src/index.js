import express from "express";
import cors from "cors";
import {WebSocketServer} from "ws";
import {createServer} from "http";
import crypto from "crypto";

const app=express();app.use(cors());app.get("/health",(_,res)=>res.json({ok:true,service:"hazari-server"}));
const server=createServer(app);const wss=new WebSocketServer({server});
const rooms=new Map();

function code(){return crypto.randomBytes(2).toString("hex").toUpperCase();}
function send(ws,msg){if(ws.readyState===1)ws.send(JSON.stringify(msg))}
function broadcast(room,msg){for(const p of room.players)send(p.ws,msg)}
function publicPlayers(room){return room.players.map(p=>({id:p.id,name:p.name,connected:p.ws?.readyState===1,bot:p.bot}))}

function addBots(room){
 while(room.players.length<4) room.players.push({id:room.players.length,name:`Bot ${room.players.length}`,bot:true,connected:true,ws:null});
}

wss.on("connection",ws=>{
 ws.on("message",raw=>{
  let m;try{m=JSON.parse(raw)}catch{return}
  if(m.type==="create"){
   let c=code();while(rooms.has(c))c=code();
   const room={code:c,host:null,players:[],started:false};
   const p={id:0,name:String(m.name||"Player"),ws,bot:false};room.host=p;room.players.push(p);rooms.set(c,room);ws.room=c;
   send(ws,{type:"room",code:c,players:publicPlayers(room)});
  } else if(m.type==="join"){
   const room=rooms.get(String(m.code||"").toUpperCase());
   if(!room)return send(ws,{type:"error",message:"Room not found"});
   if(room.started||room.players.filter(p=>!p.bot).length>=4)return send(ws,{type:"error",message:"Room is full"});
   const id=room.players.length;room.players.push({id,name:String(m.name||`Player ${id+1}`),ws,bot:false});ws.room=room.code;
   broadcast(room,{type:"room",code:room.code,players:publicPlayers(room)});
  } else if(m.type==="start"){
   const room=rooms.get(ws.room);if(!room||room.host.ws!==ws)return;
   addBots(room);room.started=true;
   broadcast(room,{type:"state",message:"Game started",players:publicPlayers(room)});
  }
 });
 ws.on("close",()=>{
  const room=rooms.get(ws.room);if(!room)return;
  const p=room.players.find(x=>x.ws===ws);if(p)p.ws=null;
  broadcast(room,{type:"state",message:"A player disconnected",players:publicPlayers(room)});
 });
});
const PORT=process.env.PORT||8787;server.listen(PORT,()=>console.log(`Hazari server listening on ${PORT}`));
