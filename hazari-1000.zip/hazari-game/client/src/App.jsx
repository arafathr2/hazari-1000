import React,{useEffect,useMemo,useRef,useState} from "react";
import {createRoot} from "react-dom/client";
import {autoArrange,cardKey,deck,evaluateGroup,GROUP_SIZES,rankValue,shuffle,trickPoints,validArrangement,trickWinner} from "./game";
import "./style.css";

const API = import.meta.env.VITE_WS_URL || `ws://${location.hostname}:8787`;

function Card({c,selected,onClick,small=false}){return <button className={`card ${c.suit==="♥"||c.suit==="♦"?"red":""} ${selected?"selected":""} ${small?"small":""}`} onClick={onClick}><span>{c.rank}</span><span>{c.suit}</span></button>}
export default function App(){
 const [mode,setMode]=useState("single"),[screen,setScreen]=useState("home"),[hand,setHand]=useState([]),[groups,setGroups]=useState([[],[],[],[]]);
 const [selected,setSelected]=useState([]),[players,setPlayers]=useState([]),[scores,setScores]=useState([0,0,0,0]),[round,setRound]=useState(0),[plays,setPlays]=useState([]),[leader,setLeader]=useState(0);
 const [room,setRoom]=useState(""),[name,setName]=useState("You"),[ws,setWs]=useState(null),[status,setStatus]=useState("");
 const [botHands,setBotHands]=useState([]),[botGroups,setBotGroups]=useState([]);
 const [turn,setTurn]=useState(0),[gameWinner,setGameWinner]=useState(null);

 const arrange=()=>{const g=autoArrange(hand);setGroups(g);setStatus(validArrangement(g)?"Arrangement valid":"Could not find a valid descending arrangement");};
 const startSingle=()=>{
   const d=shuffle(deck()), hs=[d.slice(0,13),d.slice(13,26),d.slice(26,39),d.slice(39)];
   setHand(hs[0]);setBotHands(hs.slice(1));setBotGroups(hs.slice(1).map(autoArrange));setGroups(autoArrange(hs[0]));
   setScores([0,0,0,0]);setRound(0);setLeader(0);setTurn(0);setPlays([]);setGameWinner(null);setScreen("game");
 };
 const moveSelected=(gi)=>{
   if(!selected.length)return;
   const newGroups=groups.map(g=>g.filter(c=>!selected.includes(cardKey(c))));
   const cards=hand.filter(c=>selected.includes(cardKey(c)));
   if(newGroups[gi].length+cards.length>GROUP_SIZES[gi]){setStatus("That group is full");return}
   newGroups[gi]=[...newGroups[gi],...cards];setGroups(newGroups);setSelected([]);
 };
 const cardsInGroups=useMemo(()=>groups.flat().map(cardKey),[groups]);
 const unassigned=hand.filter(c=>!cardsInGroups.includes(cardKey(c)));

 const submitArrangement=()=>{if(!validArrangement(groups)){setStatus("Groups must be 3-3-3-4 and descending in strength");return}setStatus("");setTurn(leader);setScreen("tricks")};
 const playRound=()=>{
   // Human leads when turn==0; otherwise bots act automatically.
   if(turn!==0)return;
   const cards=groups[round]||[]; if(!cards.length)return;
   const next=[{playerId:0,cards}];
   for(let i=1;i<4;i++) next.push({playerId:i,cards:botGroups[i-1][round]});
   setPlays(next);
   const w=trickWinner(next);const pts=trickPoints(next.flatMap(p=>p.cards));
   setScores(s=>s.map((v,i)=>i===w?v+pts:v));
   setStatus(`Player ${w===0?"You":w+1} won round ${round+1} (+${pts})`);
   setLeader(w);
   if(round===3){
     setGameWinner(w);setScreen("result");
   } else {setRound(round+1);setTurn(w);}
 };
 useEffect(()=>{if(screen==="tricks"&&turn!==0){const t=setTimeout(playRound,700);return()=>clearTimeout(t)}},[screen,turn,round]);

 const createRoom=()=>{
   const socket=new WebSocket(API);setWs(socket);
   socket.onopen=()=>{socket.send(JSON.stringify({type:"create",name}));};
   socket.onmessage=e=>{const m=JSON.parse(e.data);if(m.type==="room"){setRoom(m.code);setPlayers(m.players);setScreen("lobby")}if(m.type==="state"){setPlayers(m.players||[]);setStatus(m.message||"")}};
   socket.onerror=()=>setStatus("Server unavailable. Run the server and try again.");
 };
 const joinRoom=()=>{
   const socket=new WebSocket(API);setWs(socket);
   socket.onopen=()=>socket.send(JSON.stringify({type:"join",code:room.toUpperCase(),name}));
   socket.onmessage=e=>{const m=JSON.parse(e.data);if(m.type==="room"){setRoom(m.code);setPlayers(m.players);setScreen("lobby")}if(m.type==="error")setStatus(m.message)};
 };
 const launchMultiplayer=()=>ws?.send(JSON.stringify({type:"start"}));

 if(screen==="home") return <main className="shell"><header><h1>♠ Hazari <span>1000</span></h1><p>Traditional 4-player trick-taking · mobile ready</p></header><section className="home"><button className="primary" onClick={startSingle}>Single Player</button><button onClick={()=>setScreen("multi")}>Multiplayer</button><div className="rules"><b>How to play</b><p>Arrange 13 cards into 3-3-3-4 descending groups, then play four rounds. Highest combination wins each round and captures its point cards.</p></div></section></main>;

 if(screen==="multi") return <main className="shell"><header><h1>Multiplayer</h1><button onClick={()=>setScreen("home")}>← Back</button></header><section className="panel"><input value={name} onChange={e=>setName(e.target.value)} placeholder="Your name"/><button className="primary" onClick={createRoom}>Create room</button><div className="join"><input value={room} onChange={e=>setRoom(e.target.value.toUpperCase())} maxLength={4} placeholder="4-character code"/><button onClick={joinRoom}>Join</button></div>{status&&<p className="status">{status}</p>}</section></main>;

 if(screen==="lobby") return <main className="shell"><header><h1>Room <strong>{room}</strong></h1><button onClick={()=>setScreen("home")}>Leave</button></header><section className="panel"><h2>Players</h2>{players.map((p,i)=><div className="player" key={i}><span>{p.name}</span><span>{p.connected?"●":"○"}</span></div>)}<button className="primary" onClick={launchMultiplayer}>Start game</button><p className="muted">The server can fill empty seats with AI bots.</p></section></main>;

 if(screen==="result") return <main className="shell"><header><h1>Round complete</h1></header><section className="panel result"><h2>{gameWinner===0?"You won the game!":`Player ${gameWinner+1} won the game.`}</h2>{scores.map((s,i)=><div className="score" key={i}><span>{i===0?"You":`Player ${i+1}`}</span><b>{s}</b></div>)}<button className="primary" onClick={startSingle}>Play again</button></section></main>;

 if(screen==="game") return <main className="table"><header className="tableHead"><h1>Arrange your hand</h1><div>Target: <b>1000</b></div></header><section className="arrange"><div className="groups">{groups.map((g,i)=>{const ev=evaluateGroup(g);return <div className={`group ${ev.score>=0?"valid":"invalid"}`} key={i} onClick={()=>moveSelected(i)}><div className="gtitle">Group {i+1} · {GROUP_SIZES[i]} cards <small>{ev.type}</small></div><div>{g.map(c=><Card key={cardKey(c)} c={c} small onClick={e=>{e.stopPropagation();setSelected(s=>s.includes(cardKey(c))?s.filter(x=>x!==cardKey(c)):[...s,cardKey(c)])}} selected={selected.includes(cardKey(c))}/>)}</div></div>})}</div><div className="hand"><h3>Unassigned · select cards then tap a group</h3>{unassigned.map(c=><Card key={cardKey(c)} c={c} onClick={()=>setSelected(s=>s.includes(cardKey(c))?s.filter(x=>x!==cardKey(c)):[...s,cardKey(c)])} selected={selected.includes(cardKey(c))}/>)}</div><div className="actions"><button onClick={arrange}>Auto-Arrange</button><button className="primary" onClick={submitArrangement}>Play</button></div><p className="status">{status}</p></section></main>;

 return <main className="table"><header className="tableHead"><h1>Hazari 1000</h1><div>Round {round+1}/4 · {status}</div></header><div className="arena"><div className="seat top">Player 2</div><div className="seat left">Player 3</div><div className="seat right">Player 4</div><div className="trick">{plays.length?plays.map(p=><div className="played" key={p.playerId}><span>{p.playerId===0?"You":`P${p.playerId+1}`}</span>{p.cards.map(c=><Card key={cardKey(c)} c={c} small/>)}</div>):<div className="waiting">Winner leads the next round<br/><b>{turn===0?"You":`Player ${turn+1}`}</b></div>}</div><div className="you seat bottom">You · {scores[0]}/1000</div></div><aside className="scoreboard">{scores.map((s,i)=><div key={i}><span>{i===0?"You":`P${i+1}`}</span><b>{s}</b></div>)}</aside></main>;
}

