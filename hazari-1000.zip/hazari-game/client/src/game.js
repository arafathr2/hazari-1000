export const SUITS = ["♠","♥","♦","♣"];
export const RANKS = ["2","3","4","5","6","7","8","9","10","J","Q","K","A"];
export const POINTS = Object.fromEntries(RANKS.map(r => [r, ["10","J","Q","K","A"].includes(r) ? 10 : 0]));
export const GROUP_SIZES = [3,3,3,4];

export const rankValue = r => RANKS.indexOf(r)+2;
export const cardKey = c => `${c.rank}${c.suit}`;
export const deck = () => SUITS.flatMap(s => RANKS.map(r => ({rank:r,suit:s,id:`${r}${s}`})));
export const shuffle = a => { const x=[...a]; for(let i=x.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[x[i],x[j]]=[x[j],x[i]]} return x; };

function combo3(cards){
  if(cards.length!==3) return {type:"Invalid",score:-1};
  const rs=cards.map(c=>rankValue(c.rank)).sort((a,b)=>b-a);
  const sameSuit=cards.every(c=>c.suit===cards[0].suit);
  const counts={}; rs.forEach(v=>counts[v]=(counts[v]||0)+1);
  if(Object.values(counts).includes(3)) return {type:"Troy",score:700+rs[0]};
  const uniq=[...new Set(rs)];
  const isAKQ=rs.join(",")==="14,13,12", isA23=rs.join(",")==="14,3,2";
  const seq=isAKQ?100:isA23?99:(rs[0]===rs[1]+1&&rs[1]===rs[2]+1?rs[0]:-1);
  if(seq>=0 && sameSuit) return {type:"Color Run",score:600+seq};
  if(seq>=0) return {type:"Run",score:500+seq};
  if(sameSuit) return {type:"Color",score:400+rs[0]*10+rs[1]+rs[2]/100};
  const pair=Object.entries(counts).find(([,n])=>n===2);
  if(pair){ const kicker=rs.find(v=>v!==+pair[0]); return {type:"Pair",score:300+(+pair[0])*10+kicker}; }
  return {type:"High Card",score:200+rs[0]*10+rs[1]+rs[2]/100};
}

export function evaluateGroup(cards){
  if(cards.length===3) return combo3(cards);
  if(cards.length===4){
    // Standard Hazari implementations differ on the fourth card.
    // This implementation evaluates the strongest 3-card subset, making
    // the fourth card contribute to tie-breaking only when all subsets tie.
    let best={type:"4-card",score:-1};
    for(let i=0;i<4;i++){ const sub=cards.filter((_,j)=>j!==i); const e=combo3(sub); if(e.score>best.score) best={...e,score:e.score}; }
    return best;
  }
  return {type:"Invalid",score:-1};
}

export function validArrangement(groups){
  if(groups.length!==4 || groups.some((g,i)=>g.length!==GROUP_SIZES[i])) return false;
  const ev=groups.map(evaluateGroup);
  return ev.every(x=>x.score>=0) && ev[0].score>=ev[1].score && ev[1].score>=ev[2].score && ev[2].score>=ev[3].score;
}

function combinations(arr,n){
  if(n===0) return [[]]; const out=[];
  for(let i=0;i<=arr.length-n;i++) for(const tail of combinations(arr.slice(i+1),n-1)) out.push([arr[i],...tail]);
  return out;
}

export function autoArrange(hand){
  // Exact search over 3/3/3/4 partitions. 13C3*10C3*7C3 is small enough
  // for a browser, and it guarantees a valid descending partition when one exists.
  const search=(remaining, groups)=>{
    const idx=groups.length, need=GROUP_SIZES[idx];
    if(idx===3){
      const g=remaining.slice(); if(g.length!==4) return null;
      const gs=[...groups,g]; return validArrangement(gs)?gs:null;
    }
    const candidates=combinations(remaining,need)
      .map(g=>({g,e:evaluateGroup(g)})).sort((a,b)=>b.e.score-a.e.score);
    for(const c of candidates){
      const next=remaining.filter(x=>!c.g.includes(x));
      const r=search(next,[...groups,c.g]); if(r) return r;
    }
    return null;
  };
  const result=search(hand,[]);
  if(result) return result;
  // Fallback: sort by individual strength, then split.
  const sorted=[...hand].sort((a,b)=>rankValue(b.rank)-rankValue(a.rank));
  return [sorted.slice(0,3),sorted.slice(3,6),sorted.slice(6,9),sorted.slice(9)];
}

export function trickWinner(plays){
  let best=plays[0], bestE=evaluateGroup(best.cards);
  for(const p of plays.slice(1)){const e=evaluateGroup(p.cards);if(e.score>bestE.score){best=p;bestE=e.score}}
  return best.playerId;
}
export const trickPoints = cards => cards.reduce((n,c)=>n+POINTS[c.rank],0);
