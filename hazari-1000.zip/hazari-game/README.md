# Hazari 1000

A mobile-responsive Hazari (1000 Points) game with:
- Single-player mode against 3 algorithmic bots.
- Room-code multiplayer transport using WebSockets.
- 13-card deal and 3-3-3-4 arrangement.
- Exact partition search for Auto-Arrange.
- Combination evaluation: Troy, Color Run, Run, Color, Pair, High Card.
- Four trick rounds, point capture and cumulative scoring.
- Casino-green responsive UI.

## Run locally

Requires Node.js 20+.

```bash
npm install
npm run dev
```

Client: http://localhost:5173  
Server: ws://localhost:8787

For production:

```bash
npm run build
npm start
```

Set `VITE_WS_URL=wss://your-server.example.com` when building the client for a deployed WebSocket server.

## Deploy

### Server
Deploy `server` (or the repository root with the workspace install) to Render, Railway, Fly.io, or another Node host. The server listens on `PORT`.

### Client
Deploy `client/dist` to Netlify, Vercel, Cloudflare Pages, or any static host. Configure:
`VITE_WS_URL=wss://YOUR-SERVER-HOST`

## Important Hazari rule variation

Hazari has regional/rule-set differences, especially the treatment of the 4-card group and tie-breaking. This implementation uses the strongest 3-card subset of the 4-card group for evaluation, matching the requested "highest 3 cards count" interpretation. If your local table uses a different standard 4-card rule, change `evaluateGroup()` in `client/src/game.js`.

## Multiplayer production hardening

For a real public launch, move authoritative game state to the server rather than trusting the browser, persist rooms in Redis/Firestore/Supabase, validate every move server-side, add reconnection tokens, rate limits, authentication, and HTTPS/WSS.
